package Go;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import java.text.DecimalFormat;
import javafx.stage.Stage;


import java.util.ArrayList;

/**
 * This class links the Leaderboard functionality to the GUI.
 * @author Dylan Jones
 * @version 1.4
 */
public class LeaderboardController {

    @FXML private VBox parent;

    private ArrayList<User> users;
    private Stage primaryStage;
    private User user1;

    public LeaderboardController() {
        users = User.getUsersFromFile();
    }

    public void initialize() {
        updateTable();
    }

    public void setUser1(User user) {
        user1 = user;
    }

    public void setPrimaryStage(Stage stage) {
        primaryStage = stage;
    }

    public void updateTable(){
        Leaderboard leaderboard = new Leaderboard(users);
        leaderboard.sortByPercentage();
        users = leaderboard.getRankings();
        for (int i = 0; i < users.size(); i++){
            Label rank = new Label();
            rank.setText(Integer.toString(i + 1));
            rank.setPrefWidth(50.0);
            rank.setAlignment(Pos.CENTER);
            Label userName = new Label();
            userName.setText(users.get(i).getUserName());
            userName.setPrefWidth(329.0);
            userName.setAlignment(Pos.CENTER);
            Label winPercentage = new Label();
            DecimalFormat df = new DecimalFormat("0.00");
            df.setMaximumFractionDigits(2);
            String stringPercentage = df.format(users.get(i).getWinPercentage());
            winPercentage.setText(stringPercentage + "%");
            winPercentage.setPrefWidth(300.0);
            winPercentage.setAlignment(Pos.CENTER);
            HBox box = new HBox();
            box.getChildren().add(rank);
            box.getChildren().add(userName);
            box.getChildren().add(winPercentage);
            box.setAlignment(Pos.CENTER);
            box.setMargin(rank, new Insets(10, 0, 10, 0 ));
            box.setMargin(userName, new Insets(10, 0, 10, 0 ));
            box.setMargin(winPercentage, new Insets(10, 0, 10, 0 ));
            if (i%2 == 1) {
                box.setStyle("-fx-background-color:#f7f7f7");
            }
            parent.getChildren().addAll(box);
        }
    }

    public void newGame() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("GoBoard.fxml"));
            Parent root = (Parent) loader.load();
            Scene scene = new Scene(root, 800, 400);
            BoardController controller = loader.getController();
            controller.setPrimaryStage(primaryStage);
            controller.setUser1(user1);
            primaryStage.setScene(scene);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void logOut() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Start.fxml"));
            Parent root = (Parent) loader.load();
            Scene scene = new Scene(root, 800, 400);
            StartController controller = loader.getController();
            controller.setPrimaryStage(primaryStage);
            primaryStage.setScene(scene);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }
}