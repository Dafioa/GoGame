package Go;

/**
 * This class represents a map of the owned territories on the board.
 * @author Dylan Jones
 * @version 1.0
 */
public class TerritoryMap {
  private int boardSize;
  private int[][] territories;
  private boolean[][] territoriesChecked;

  /**
   * Create a map of territories, initially with all neutral (0).
   * @param size the size of the board to map.
   */
  public TerritoryMap(final int size) {
    boardSize = size;
    territories = new int[boardSize][boardSize];
    territoriesChecked = new boolean[boardSize][boardSize];
  }

  /**
   * Set the territory value at a particular point.
   * @param coord the coordinate of the point to set.
   * @param terr the value to set to.
   */
  public void setTerritory(final int[] coord, final int terr) {
    final int x = coord[0];
    final int y = coord[1];
    territories[x][y] = terr;
    territoriesChecked[x][y] = true;
  }

  /**
   * Get whether a particular point has had territory set.
   * @param coord the coordinate of the point to check.
   * @return boolean representing whether this point has had territory set.
   */
  public boolean getCheckState(final int[] coord) {
    final int x = coord[0];
    final int y = coord[1];
    return territoriesChecked[x][y];
  }

  /**
   * Counts the territories for each player.
   * @return an int[2] object containing Player 1's score and Player 2's score.
   */
  public int[] countTerritories() {
    int player1Score = 0;
    int player2Score = 0;
    for (int x = 0; x < boardSize; x++) {
      for (int y = 0; y < boardSize; y++) {
        if (territories[x][y] == 1) {
          player1Score++;
        } else if (territories[x][y] == 2) {
          player2Score++;
        }
      }
    }
    final int[] scores = {player1Score, player2Score};
    return scores;
  }

  /**
   * Prints territories for all points on board to console (for testing only).
   */
  public void printTerritories() {
    for (int y = boardSize - 1; y >= 0;  y--) {
      for (int x = 0; x < boardSize; x++) {
        System.out.print(territories[x][y] + ", ");
      }
      System.out.println(" ");
    }
  }
}
