package Go;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * Launches the application.
 * @author Dylan Jones
 * @version 1.2
 */
public class Main extends Application {
    public static final int APP_WIDTH = 800;
    public static final int APP_HEIGHT = 400;

    /**
     * Starts the application.
     * @param primaryStage the stage for running the application.
     */
    @Override
    public void start(final Stage primaryStage) {
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("Start.fxml")
            );
            Parent root = (Parent) loader.load();
            StartController controller = loader.getController();
            controller.setPrimaryStage(primaryStage);
            Scene scene = new Scene(root, APP_WIDTH, APP_HEIGHT);

            primaryStage.setTitle("Go94");
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(final String[] args) {
        launch(args);
    }
}
