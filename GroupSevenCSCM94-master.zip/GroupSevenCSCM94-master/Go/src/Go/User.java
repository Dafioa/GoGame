package Go;

import java.io.BufferedReader;
import java.io.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * This class represents each user that can use the system.
 * @author Dafydd
 * @version 1.8
 */
public class User {
  public static final String USER_FILE = "lib/Users.txt";
  private String userName;
  private String firstName;
  private String lastName;
  private Date lastLogin = new Date();
  private int winNumber;
  private int lossNumber;
  private double winPercentage;
  private String profilePicture;

  public User(final String a, final String b, final String c, final int imageNo) {
    userName = a;
    firstName = b;
    lastName = c;
    winNumber = 0;
    lossNumber = 0;
    winPercentage = 0;
    profilePicture = "thing" + imageNo + ".png";
    lastLogin = Calendar.getInstance().getTime();
  }

  public static ArrayList<User> getUsersFromFile() {
    ArrayList<User> users = new ArrayList<>();
    try {
      FileReader fileReader = new FileReader(USER_FILE);
      BufferedReader bufferedReader = new BufferedReader(fileReader);
      String line = null;
      while ((line = bufferedReader.readLine()) != null) {
        String[] userStrings = line.split(" ");
        User user = new User(
            userStrings[0],
            userStrings[1],
            userStrings[2],
            Integer.parseInt(userStrings[3]));
        user.setWinRecord(Integer.parseInt(userStrings[4]), Integer.parseInt(userStrings[5]));
        users.add(user);
      }
      bufferedReader.close();
    }
    catch(FileNotFoundException e) {
      e.printStackTrace();
    }
    catch(IOException e) {
      e.printStackTrace();
    }
    return users;
  }

  public static void downloadToFile(User user) {
    ArrayList<User> users = getUsersFromFile();
    try {
      FileWriter fileWriter = new FileWriter(USER_FILE, false);
      BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
      PrintWriter printWriter = new PrintWriter(bufferedWriter);
      boolean userFound = false;
      for (User u : users) {
        if (u.getUserName().equals(user.getUserName())) {
          u.setEqualTo(user);
        }
        String picNo = u.getProfilePicture().substring(5,6);
        printWriter.write(
          u.getUserName()
          + " "
          + u.getFirstName()
          + " "
          + u.getLastName()
          + " "
          + picNo
          + " "
          + u.getWinNumber()
          + " "
          + u.getLossNumber()
        );
        printWriter.println(" ");
      }
      printWriter.close();
    }
    catch (IOException e) {
      e.printStackTrace();
    }
  }

  public void updateLastLogin() {
    lastLogin = Calendar.getInstance().getTime();
  }

  public double updateWinRecord(final boolean isWin) {
    if (isWin) winNumber++;
    else lossNumber++;
    double totalGames = (double) (winNumber + lossNumber);
    winPercentage = 100.0 * ((double) winNumber / totalGames);
    return winPercentage;
  }

  public String getFirstName() {
    return firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public Date getLastLogin() {
    return lastLogin;
  }

  public int getLossNumber() {
    return lossNumber;
  }

  public double getWinPercentage() {
    return winPercentage;
  }

  public int getWinNumber() {
    return winNumber;
  }

  public String getUserName() {
    return userName;
  }

  public void setWinRecord(final int winNo, final int lossNo) {
    winNumber = winNo;
    lossNumber = lossNo;
    double totalGames = (double) (winNumber + lossNumber);
    winPercentage = 100.0 * ((double) winNumber / totalGames);
  }

  public String getProfilePicture() {
    return profilePicture;
  }

  public void setEqualTo(User user) {
    userName = user.getUserName();
    firstName = user.getFirstName();
    lastName = user.getLastName();
    lastLogin = user.getLastLogin();
    winNumber = user.getWinNumber();
    lossNumber = user.getLossNumber();
    winPercentage = user.getWinPercentage();
    profilePicture = user.getProfilePicture();
  }

  public static void main(String[] args) {
    User Greg = new User("GrandMaster Greggy", "Greg", "Stait", 3);
  }
}