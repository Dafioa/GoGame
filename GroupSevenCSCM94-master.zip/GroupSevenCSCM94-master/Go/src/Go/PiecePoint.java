package Go;

 /**
  * This class represents a point on the go board where a piece can be placed.
  * @author Dylan Jones
  * @version 1.3
  */
public class PiecePoint {
  public static final int NEUTRAL_STATE = 0;
  public static final int P1_STATE = 1;
  public static final int P2_STATE = 2;
  public static final int FALSE_STATE = 3; // used to signify no state returned
  private int[] coordinate;
  private int state;
  private int liberties;
  private int[][] adjacentPoints;
  private boolean checked;

  /**
   * Create a new point.
   * @param coord the coordinate of the point.
   * @param adjPoints an array of the coordinates of adjacent points.
   */
  public PiecePoint(final int[] coord, final int[][] adjPoints) {
    coordinate = coord;
    state = NEUTRAL_STATE;
    liberties = adjPoints.length;
    adjacentPoints = adjPoints;
    checked = false;
  }

  /**
   * Get the coordinate of the point on the board.
   * @return the coordinate of the point.
   */
  public int[] getCoordinate() {
    return coordinate;
  }

  /**
   * Get the state of the point (i.e. if there is a piece on it and what type).
   * @return the state of the point.
   */
  public int getState() {
    return state;
  }

  /**
   * Update the state of the point.
   * @param newState the state to be updated to.
   * @throws IllegalArgumentException where newState is not one of 0,1,2.
   */
  public void updateState(final int newState) {
    if (newState != P1_STATE
        && newState != P2_STATE
        && newState != NEUTRAL_STATE
    ) {
      throw new IllegalArgumentException(
        "Point state can be 0,1,2, input value: "
        + newState
      );
    }
    state = newState;
    return;
  }

  /**
   * Get the number of liberties for the point.
   * @return the number of liberties for the point.
   */
  public int getLiberties() {
    return liberties;
  }

  /**
   * Increase the number of liberties for the point by 1.
   * @throws IllegalStateException if liberties are at maximum.
   */
  public void increaseLiberties() {
    if (liberties >= adjacentPoints.length) {
      throw new IllegalStateException(
        "Cannot increase point liberties above maximum"
      );
    }
    liberties++;
    return;
  }

  /**
   * Decrease the number of liberties for the point by 1.
   * @throws IllegalStateException if liberties are at minimum (i.e. zero).
   */
  public void decreaseLiberties() {
    if (liberties <= 0) {
      throw new IllegalStateException(
        "Cannot decrease liberties below 0"
      );
    }
    liberties--;
    return;
  }

  /**
   * Get the adjacent points of the point.
   * @return the adjacentPoints array of the point.
   */
  public int[][] getAdjacentPoints() {
    return adjacentPoints;
  }

  /**
   * Get the checked status of the point.
   * @return whether the point has been checked.
   */
  public boolean getChecked() {
    return checked;
  }

  /**
   * Set the value of checked to the value passed.
   * @param checkedValue the new value to set to.
   */
  public void setChecked(final boolean checkedValue) {
    checked = checkedValue;
    return;
  }

  /**
   * Check if this PiecePoint is equal to another.
   * @param otherPoint the point to compare against.
   * @return true if points equal, false otherwise.
   */
  public boolean equals(final PiecePoint otherPoint) {
    boolean coordinateEqual = true;
    for (int i = 0; i < coordinate.length; i++) {
      if (coordinate[i] != otherPoint.getCoordinate()[i]) {
        coordinateEqual = false;
      }
    }
    boolean stateEqual = state == otherPoint.getState();
    boolean libertiesEqual = liberties == otherPoint.getLiberties();
    return coordinateEqual && stateEqual && libertiesEqual;
  }

  /**
   * Set PiecePoint object to be equal to another BoardState object.
   * @param otherPoint the point to compare against.
   */
  public void setEqualTo(final PiecePoint otherPoint) {
    state = otherPoint.getState();
    liberties = otherPoint.getLiberties();
    checked = otherPoint.getChecked();
  }
}
