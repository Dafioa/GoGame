package Go;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.io.*;

/**
 * Instigates users into the GUI from the data file and sets the stage.
 * @author Dylan Jones
 * @version 1.2
 */
public class StartController {

  @FXML private ChoiceBox<String> userList;
  @FXML private ImageView goImageView;
  @FXML private Button goButton;

  private ArrayList<User> users;
  private User selectedUser;
  private Stage primaryStage;

  /**
   * Creates an instance of the controller loading in users from a file.
   */
  public StartController() {
    users = User.getUsersFromFile();
  }

  /**
   * Initializes the Start page.
   */
  public void initialize() {
    File imageFile = new File("lib/Images/GoTitle.png");
    Image goImage = new Image(imageFile.toURI().toString());
    goImageView.setImage(goImage);
    refreshUserList();
  }

  /**
   * Sets the stage in which to display the scene.
   * @param stage the stage to set to.
   */
  public void setPrimaryStage(final Stage stage) {
    primaryStage = stage;
  }

  /**
   * Update page on user action.
   */
  public void updatePage() {
    if (userList.getValue() != null) {
      goButton.setDisable(false);
      for (User u : users) {
        if (u.getUserName() == userList.getValue()) {
          selectedUser = u;
        }
      }
    }
  }

  /**
   * Add users to dropdown list.
   */
  public void refreshUserList() {
    userList.getItems().clear();
    for (User u : users) {
      userList.getItems().add(u.getUserName());
    }
  }

  /**
   * Redirects to the GoBoard page of the app.
   */
  public void go() {
    selectedUser.updateLastLogin();
    try {
      FXMLLoader loader = new FXMLLoader(
          getClass().getResource("GoBoard.fxml")
      );
      Parent root = (Parent) loader.load();
      Scene scene = new Scene(root, Main.APP_WIDTH, Main.APP_HEIGHT);
      BoardController controller = loader.getController();
      controller.setPrimaryStage(primaryStage);
      controller.setUser1(selectedUser);
      primaryStage.setScene(scene);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
