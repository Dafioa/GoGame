package Go;

import java.util.Date;

/**
 *This class contains the functionality for carrying out a game of go.
 * @author Greg Stait
 * @version 1.4
 */
class Game {
  private static int previousGameId = 0;
  final private int gameId; //unique identifier for tracking game results
  private User playerOne;
  private User playerTwo;
  private int moveCounter;
  private int playerOneScore;
  private int playerTwoScore;
  private int passCounter;
  private int currentTurn;
  private BoardState currentBoard;
  private BoardState previousBoard;

  /**
   * Create a new game.
   * @param size the size of the board.
   * @param _playerOne the first user.
   * @param _playerTwo the second user.
   * Black will be playerOne and player Two will be white.
   */
  public Game(final int size, final User _playerOne, final User _playerTwo) {
    currentBoard =  new BoardState(size);
    previousBoard = new BoardState(size);
    // calculate which player should go first based on win records
    if (_playerOne.getWinPercentage() < _playerTwo.getWinPercentage()) {
      playerOne = _playerOne;
      playerTwo = _playerTwo;
    }
    else {
      playerOne = _playerTwo;
      playerTwo = _playerOne;
    }
    gameId = previousGameId + 1;
    previousGameId++;
    moveCounter = 0;
    playerOneScore = 0;
    playerTwoScore = 0;
    passCounter = 0;
    currentTurn = 1;
  }

  /**
   * Access the gameId variable.
   * @return the id for the game.
   */
  public int getGameId() {
    return gameId;
  }

  /**
   * Access the moveCounter variable.
   * @return the amount of moves taken.
   */
  public int getMoveCounter() {
    return moveCounter;
  }
  
  /**
   * Increase the move counter by 1.
   */
  public void incMoveCounter() {
    moveCounter++;
    currentTurn = moveCounter%2 + 1;
  }

  /**
   * Access playerOneScore variable.
   * @return scores for both players.
   */
  public int[] getScores() {
    final int[] scores = {playerOneScore, playerTwoScore};
    return scores;
  }

  public User getPlayerOne() {
    return playerOne;
  }

  public User getPlayerTwo() {
    return playerTwo;
  }

  public int getCurrentTurn() {
    return currentTurn;
  }

  public int getPointState(final int x, final int y) {
    return currentBoard.getPoint(x, y).getState();
  }

  /**
   * Compares current state of play to previous state to ensure that no move breaking ko is occurring.
   * @param checkBoard the the board to check against the previous board.
   * @return a boolean confirming whether the board states equal one another.
   */
  public boolean checkForKo(final BoardState checkBoard) {
    return checkBoard.equals(previousBoard);
  }

  public boolean checkForSuicide(final BoardState checkBoard, final int x, final int y) {
    return checkBoard.captureSelf(x, y);
  }

  /**
   * Attempts to make a move by placing a piece on a given point.
   * @param x the x coordinate of the PiecePoint.
   * @param y the y coordinate of the PiecePoint.
   */
  public void makeMove(final int x, final int y) {
  //temporary board for ko comparison
    BoardState temp = new BoardState(currentBoard.getSize());
    temp.setEqualTo(currentBoard);
    boolean validMove = temp.placePiece(x, y, currentTurn);
    int captureCount = temp.captureFromPiece(x, y);
    if (validMove) {
      //checks the move made on a temporary board first
      if (checkForSuicide(temp, x, y)) {
        return;
      }
      if (checkForKo(temp)) {
        return;
      } 
      else {
        //if the move is legal - both boards are updated
        previousBoard.setEqualTo(currentBoard);
        currentBoard.setEqualTo(temp);
        //increments scores depending on whether a piece/s was captured
        if (currentTurn == 1) {
          playerOneScore += captureCount;
        } else {
          playerTwoScore += captureCount;
        }
        incMoveCounter();
        //resets pass counter
        passCounter = 0;
      }
    }
  }
  
  /**
  * Passes the current turn.
  */
  public void pass() {
    passCounter++;
    incMoveCounter();
  }

  /**
   * Establishes when the game is complete
   * @return returns state of game
   */
  public boolean checkIfGameFinished() {
    if (passCounter > 2) {
      return true;
    }
    else {
      return false;
    }
  }
  
  /**
   * Calculate final scores for the game and update User records.
   */
  public void calculateEndScores() {
    int[] territoryScores = new int[2]; //create an array for territory scores
    territoryScores = currentBoard.countTerritories();
    playerOneScore += territoryScores[0];
    playerTwoScore += territoryScores[1];
    // updates the amount of wins/losses for both users depending on the winner
    if (playerOneScore > playerTwoScore) {
      playerOne.updateWinRecord(true);
      playerTwo.updateWinRecord(false);
    }
    else if (playerTwoScore > playerOneScore){
      playerOne.updateWinRecord(false);
      playerTwo.updateWinRecord(true);
    }
    User.downloadToFile(playerOne);
    User.downloadToFile(playerTwo);
  }
}