package Go;

import java.util.ArrayList;

/**
 * This class creates the user Leaderboard based on user records.
 * @author Dafydd Watkins
 * @version 1.3
 */
public class Leaderboard {
  private ArrayList<User> Rankings;

  public Leaderboard(ArrayList<User> _Users){
    Rankings = _Users;
  }

  public ArrayList<User> getRankings() {
    return Rankings;
  }

  public void sortByPercentage() {

    int N = Rankings.size();

    boolean sorted = false;
    while(!sorted) {
      boolean check = true;
      for (int i = 0; i < N - 1; i++) {
        double nextWinPercentage = Rankings.get(i + 1).getWinPercentage();
        double thisWinPercentage = Rankings.get(i).getWinPercentage();
        if (nextWinPercentage > thisWinPercentage) {
          User temp = new User("temp", "temp", "temp", 1);
          temp.setEqualTo(Rankings.get(i));
          Rankings.get(i).setEqualTo(Rankings.get(i + 1));
          Rankings.get(i + 1).setEqualTo(temp);
          check = false;
        }
      }
      if (check) {
        sorted = true;
      }
    }
  }

  public void sortByWins() {

    int N = Rankings.size();

    for (int i = 1; i < N; ++i) {
      User key = Rankings.get(i);
      int j = i - 1;

      while (j >= 0 && Rankings.get(j).getWinNumber() < key.getWinNumber()) {
        Rankings.get(j + 1).setEqualTo(Rankings.get(j));
        j = j - 1;
      }
      Rankings.get(j + 1).setEqualTo(key);
    }

  }

  public ArrayList<Integer> wins(){
    int N = Rankings.size();
    ArrayList<Integer> win = new ArrayList<Integer>();

    for(int i = 0; i < N; i++){
      win.set(i, Rankings.get(i).getWinNumber());
    }
    return win;
  }

  public ArrayList<Double> winPercent(){
    int N = Rankings.size();
    ArrayList<Double> percent = new ArrayList<Double>();

    for (int i = 0; i < N; i++){
      percent.set(i, Rankings.get(i).getWinPercentage());
    }
    return percent;
  }

  public ArrayList<String> players(){
    int N = Rankings.size();
    ArrayList<String> player = new ArrayList<String>();

    for (int i = 0; i < N; i++){
      player.set(i, Rankings.get(i).getUserName());
    }

    return player;
  }


}