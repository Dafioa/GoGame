package Go;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.paint.CycleMethod;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.Stop;
import javafx.scene.paint.RadialGradient;
import javafx.scene.Cursor;
import javafx.scene.control.Label;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import java.io.File;
import java.util.ArrayList;

/** This class controls the board on the GUI during a game of go.
 * @author Dylan Jones
 * @version 1.6
 */
public class BoardController {
  private static final double BOARDSTART_X = 32;
  private static final double BOARDSTART_Y = 32;
  private static final double BOARDSPACING = 42;
  private static final int BOARDSIZE = 9;

  @FXML private Pane gameboard;
  @FXML private Label playerOneUsername;
  @FXML private Label playerTwoUsername;
  @FXML private ImageView playerOneImage;
  @FXML private ImageView playerTwoImage;
  @FXML private Label playerOneScore;
  @FXML private Label playerTwoScore;
  @FXML private ImageView playerOneScoreImage;
  @FXML private ImageView playerTwoScoreImage;
  @FXML private Button pass1;
  @FXML private Button pass2;
  @FXML private ChoiceBox selectPlayer2List;
  @FXML private Button goButton;
  @FXML private VBox selectPlayer2Box;
  @FXML private Pane gameOverBox;
  @FXML private Rectangle player1ColourMarker;
  @FXML private Rectangle player2ColourMarker;

  private Circle[][] pieces;
  private Label gameOverText;
  private RadialGradient white;
  private RadialGradient black;
  private Game thisGame;
  private Image winImage;
  private Image lossImage;
  private Image drawImage;
  private Rectangle clickShield;
  private Button newGameButton;
  private Button leaderBoardButton;
  private User user1;
  private User user2;
  private boolean user1GoesFirst;
  private Stage primaryStage;
  private ArrayList<User> users;

  /**
   * Creates a new instance of the page.
   * Initializes some javaFX objects that will be needed.
   */
  public BoardController() {
    white = new RadialGradient(
        0,
        0,
        0.5,
        0.5,
        1.0,
        true,
        CycleMethod.NO_CYCLE,
        new Stop(0, Color.WHITE),
        new Stop(0.5, Color.web("#dadada")),
        new Stop(1.0, Color.web("#6f6e6e"))
    );
    black = new RadialGradient(
        0,
        0,
        0.5,
        0.5,
        1.0,
        true,
        CycleMethod.NO_CYCLE,
        new Stop(0, Color.web("#464646")),
        new Stop(1.0, Color.BLACK)
    );
    users = User.getUsersFromFile();
    File winImageFile = new File("lib/Images/winner.gif");
    winImage = new Image(winImageFile.toURI().toString());
    File lossImageFile = new File("lib/Images/loser.gif");
    lossImage = new Image(lossImageFile.toURI().toString());
    File drawImageFile = new File("lib/Images/draw.gif");
    drawImage = new Image(drawImageFile.toURI().toString());
    clickShield = new Rectangle();
    clickShield.setLayoutX(8.5);
    clickShield.setLayoutY(9);
    clickShield.setFill(Color.web("#bababa00"));
    clickShield.setHeight(383);
    clickShield.setWidth(383);
  }

  /**
   * Initializes the GoBoard page.
   */
  @FXML
  public void initialize() {
    pieces =  new Circle[BOARDSIZE][BOARDSIZE];
    for (int x = 0; x < BOARDSIZE; x++) {
      for (int y = 0; y < BOARDSIZE; y++) {
        Circle piece = new Circle();
        piece.setLayoutX(BOARDSTART_X + (x * BOARDSPACING));
        piece.setLayoutY(BOARDSTART_Y + (y * BOARDSPACING));
        piece.setRadius(17);
        piece.setStroke(Color.web("#bababa00"));
        piece.setFill(Color.web("#bababa00"));
        piece.setCursor(Cursor.HAND);
        final int xcoord = x;
        final int ycoord = y;
        piece.setOnMouseClicked(event -> updateBoard(xcoord, ycoord));
        pieces[x][y] = piece;
        gameboard.getChildren().add(piece);
      }
    }
    gameboard.getChildren().add(clickShield);
  }

  /**
   * Updates the board to reflect a player move.
   * @param x0 the x coordinate of the point played.
   * @param y0 the y coordinate of teh point player.
   */
  public void updateBoard(final int x0, final int y0) {
    thisGame.makeMove(x0, y0);
    int[] scores = thisGame.getScores();
    updatePlayerScores(scores);
    for (int x = 0; x < BOARDSIZE; x++) {
      for (int y = 0; y < BOARDSIZE; y++) {
        int state = thisGame.getPointState(x, y);
        switch (state) {
          case 0:
            pieces[x][y].setFill(Color.web("#bababa00"));
            pieces[x][y].setCursor(Cursor.HAND);
            break;
          case 1:
            pieces[x][y].setFill(black);
            pieces[x][y].setCursor(Cursor.DEFAULT);
            break;
          case 2:
            pieces[x][y].setFill(white);
            pieces[x][y].setCursor(Cursor.DEFAULT);
            break;
          default :
            break;
        }
      }
    }
    int turn = thisGame.getCurrentTurn();
    if ((turn == 1 && user1GoesFirst) || (turn == 2 && !user1GoesFirst)) {
      pass1.setDisable(false);
      pass2.setDisable(true);
    } else {
      pass1.setDisable(true);
      pass2.setDisable(false);
    }
  }

  /**
   * Update page when player 2 selected.
   */
  public void updatePage() {
    if (selectPlayer2List.getValue() != null) {
      goButton.setDisable(false);
      for (User u : users) {
        if (u.getUserName() == selectPlayer2List.getValue()) {
          user2 = u;
        }
      }
    }
  }

  /**
   * Start the game.
   */
  public void go() {
    thisGame = new Game(BOARDSIZE, user1, user2);
    User playerOne = thisGame.getPlayerOne();
    if (playerOne.getUserName().equals(user1.getUserName())) {
      user1GoesFirst = true;
      pass1.setDisable(false);
      player1ColourMarker.setFill(Color.BLACK);
      player2ColourMarker.setFill(Color.WHITE);
    } else {
      user1GoesFirst = false;
      pass2.setDisable(false);
      player1ColourMarker.setFill(Color.WHITE);
      player2ColourMarker.setFill(Color.BLACK);
    }
    playerTwoUsername.setText(user2.getUserName());
    File file2 = new File("lib/Images/" + user2.getProfilePicture());
    Image image2 = new Image(file2.toURI().toString());
    playerTwoImage.setImage(image2);
    selectPlayer2Box.setVisible(false);
    player1ColourMarker.setVisible(true);
    player2ColourMarker.setVisible(true);
    gameboard.getChildren().remove(clickShield);
  }

  /**
   * Reset the board for a new game.
   */
  public void resetBoard() {
    for (int x = 0; x < BOARDSIZE; x++) {
      for (int y = 0; y < BOARDSIZE; y++) {
        pieces[x][y].setFill(Color.web("#bababa00"));
      }
    }
  }

  /**
   * Pass a turn.
   */
  public void pass() {
    thisGame.pass();
    int turn = thisGame.getCurrentTurn();
    if ((turn == 1 && user1GoesFirst) || (turn == 2 && !user1GoesFirst)) {
      pass1.setDisable(false);
      pass2.setDisable(true);
    } else {
      pass1.setDisable(true);
      pass2.setDisable(false);
    }
    if (thisGame.checkIfGameFinished()) {
      endGame();
    }
  }

  /**
   * Sets the stage in which to display the scene.
   * @param stage the stage to set to.
   */
  public void setPrimaryStage(final Stage stage) {
    primaryStage = stage;
  }

  /**
   * Set the logged in user.
   * @param user the logged in user.
   */
  public void setUser1(final User user) {
    user1 = user;
    playerOneUsername.setText(user1.getUserName());
    File file1 = new File("lib/Images/" + user1.getProfilePicture());
    Image image1 = new Image(file1.toURI().toString());
    playerOneImage.setImage(image1);
    int i = 0;
    while (!user1.getUserName().equals(users.get(i).getUserName())) {
      i++;
    }
    users.remove(i);
    refreshUserList();
  }

  /**
   * Update the display of player scores to match the in game scores.
   * @param scores the in game scores.
   */
  public void updatePlayerScores(final int[] scores) {
    if (user1GoesFirst) {
      playerOneScore.setText(Integer.toString(scores[1]));
      playerTwoScore.setText(Integer.toString(scores[0]));
    } else {
      playerOneScore.setText(Integer.toString(scores[1]));
      playerTwoScore.setText(Integer.toString(scores[0]));
    }
  }

  /**
   * Add users to dropdown list.
   */
  public void refreshUserList() {
    selectPlayer2List.getItems().clear();
    for (User u : users) {
      selectPlayer2List.getItems().add(u.getUserName());
    }
  }

  /**
   * End the game.
   */
  public void endGame() {
    thisGame.calculateEndScores();
    int[] scores = thisGame.getScores();
    updatePlayerScores(scores);
    System.out.println("Game over");
    gameboard.getChildren().remove(gameOverBox);
    gameboard.getChildren().add(gameOverBox);
    gameOverBox.setVisible(true);
    if (scores[0] > scores[1]) {
      if (user1GoesFirst) {
        playerOneScoreImage.setImage(winImage);
        playerTwoScoreImage.setImage(lossImage);
      } else {
        playerTwoScoreImage.setImage(winImage);
        playerOneScoreImage.setImage(lossImage);
      }
    } else if (scores[1] > scores[0]) {
      if (user1GoesFirst) {
        playerTwoScoreImage.setImage(winImage);
        playerOneScoreImage.setImage(lossImage);
      } else {
        playerOneScoreImage.setImage(winImage);
        playerTwoScoreImage.setImage(lossImage);
      }
    } else {
      System.out.println("Draw");
      playerTwoScoreImage.setImage(drawImage);
      playerOneScoreImage.setImage(drawImage);
    }
    playerOneScoreImage.setVisible(true);
    playerTwoScoreImage.setVisible(true);
    pass1.setDisable(true);
    pass2.setDisable(true);
    player1ColourMarker.setVisible(false);
    player2ColourMarker.setVisible(false);
  }

  /**
   * Start a new game.
   */
  public void newGame() {
    gameboard.getChildren().add(clickShield);
    gameOverBox.setVisible(false);
    selectPlayer2Box.setVisible(true);
    playerOneScoreImage.setVisible(false);
    playerTwoScoreImage.setVisible(false);
    pass1.setDisable(true);
    pass2.setDisable(true);
    resetBoard();
    int[] scores = {0, 0};
    updatePlayerScores(scores);
  }

  /**
   * Redirects to the LeaderBoard page of the app.
   */
  public void goToLeaderBoard() {
    try {
      FXMLLoader loader = new FXMLLoader(
          getClass().getResource("LeaderBoard.fxml")
      );
      Parent root = (Parent) loader.load();
      Scene scene = new Scene(root, Main.APP_WIDTH, Main.APP_HEIGHT);
      LeaderboardController controller = loader.getController();
      controller.setPrimaryStage(primaryStage);
      controller.setUser1(user1);
      primaryStage.setScene(scene);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Redirects to the Start page of the app.
   */
  public void logOut() {
    try {
      FXMLLoader loader = new FXMLLoader(getClass().getResource("Start.fxml"));
      Parent root = (Parent) loader.load();
      Scene scene = new Scene(root, Main.APP_WIDTH, Main.APP_HEIGHT);
      StartController controller = loader.getController();
      controller.setPrimaryStage(primaryStage);
      primaryStage.setScene(scene);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
