package Go;

/**
* This class represents an instance of the go board.
* @author Dylan Jones
* @version 1.5
*/
public class BoardState {
  private PiecePoint[][] boardArray;
  private int boardSize;

  /**
   * Create initial board with no pieces placed.
   * @param size the size of the board to be created.
   */
  public BoardState(final int size) {
    boardSize = size;
    boardArray = new PiecePoint[boardSize][boardSize];
    //Set adjacent points and coordinate for each point
    for  (int x = 0; x < boardSize; x++) {
      for (int y = 0; y < boardSize; y++) {
        int[] coord = {x, y };
        int[][] adjacentPoints;
        if (x == 0 || x == boardSize - 1 || y == 0 || y == boardSize - 1) {
          if (x == y || Math.abs(x - y) == boardSize - 1) {
            adjacentPoints = new int[2][];
          } else {
            adjacentPoints = new int[3][];
          }
        } else {
          adjacentPoints = new int[4][];
        }
        int i = 0;
        if (y != boardSize - 1) {
          int[] upCoordinate = {x, y + 1};
          adjacentPoints[i] = upCoordinate; // Point above
          i++;
        }
        if (x != boardSize - 1) {
          int[] rightCoordinate = {x + 1, y};
          adjacentPoints[i] = rightCoordinate; //Point to right
          i++;
        }
        if (y != 0) {
          int[] downCoordinate = {x, y - 1};
          adjacentPoints[i] = downCoordinate; //  Point below
          i++;
        }
        if (x != 0) {
          int[] leftCoordinate = {x - 1, y};
          adjacentPoints[i] = leftCoordinate; // Point to left
          i++;
        }
        boardArray[x][y] = new PiecePoint(coord, adjacentPoints);
      }
    }
  }

   /**
    * Get the boardSize.
    * @return the boardSize.
    */
   public int getSize() {
     return boardSize;
  }

  /**
   * Get a particular point on the board.
   * @param x the x coordinate of the point.
   * @param y the y coordinate of the point.
   * @return the point (x,y) as a PiecePoint object.
   * @throws IllegalArgumentException where coordinates are out of bounds.
   */
  public PiecePoint getPoint(final int x, final int y) {
    if (x < 0 || x > boardSize - 1 || y < 0 || y > boardSize - 1) {
      throw new IllegalArgumentException(
        "Coordinates must be between zero and "
        + boardSize
        + " Given x: "
        + x
        + " y: "
        + y
      );
    }
    return boardArray[x][y];
  }

  /**
   * Get a particular point on the board.
   * @param coord the x,y coordinate of the point.
   * @return the point(x,y) as a PiecePoint object.
   * @throws IllegalArgumentException where coordinate is out of bounds.
   */
  public PiecePoint getPoint(final int[] coord) {
    final int x = coord[0];
    final int y = coord[1];
    return getPoint(x, y);
  }

  /**
   * Attempts to place a new piece on the board.
   * @param x the x coordinate of the point on which to place.
   * @param y the y coordinate of the point on which to place.
   * @param newState the state that the point will be updated to.
   * @return boolean indicating success of failure.
   * @throws IllegalArgumentException where coordinates are out of bounds.
   */
  public boolean placePiece(final int x, final int y, final int newState) {
    PiecePoint thisPoint = getPoint(x, y);
    if (x < 0 || x > boardSize - 1 || y < 0 || y > boardSize - 1) {
      throw new IllegalArgumentException(
        "Coordinates must be between zero and "
        + boardSize
        + " Given x: "
        + x
        + " y; "
        + y
      );
    }
    if (thisPoint.getState() != PiecePoint.NEUTRAL_STATE) {
      return false; //Cannot place piece on top of another piece
    } else {
      thisPoint.updateState(newState);
      //Update liberties for adjacent points to reflect new piece placed
      int[][] adjacentPoints = thisPoint.getAdjacentPoints();
      for (int i = 0; i < adjacentPoints.length; i++) {
        getPoint(adjacentPoints[i]).decreaseLiberties();
      }
      return true;
    }
  }

  /**
   * Prints liberties for all points on board to console (for testing only).
   */
  public void printLiberties() {
    for (int y = boardSize - 1; y >= 0;  y--) {
      for (int x = 0; x < boardSize; x++) {
        System.out.print(getPoint(x, y).getLiberties() + ", ");
      }
      System.out.println(" ");
    }
  }

  /**
   * Prints states for all points on board to console (for testing only).
   */
  public void printStates() {
    for (int y = boardSize - 1; y >= 0;  y--) {
      for (int x = 0; x < boardSize; x++) {
        System.out.print(getPoint(x, y).getState() + ", ");
      }
      System.out.println(" ");
    }
  }

  /**
   * Prints adjacent points for a single point to console (for testing only).
   * @param x the x coordinate of the point to print.
   * @param y the y coordinate of the point to print.
   */
  public void printAdjacentPoints(final int x, final int y) {
    int[][] adjacentPoints = getPoint(x, y).getAdjacentPoints();
    for (int i = 0; i < adjacentPoints.length; i++) {
      for (int j = 0; j < adjacentPoints[i].length; j++) {
       System.out.print(adjacentPoints[i][j] + ", ");
      }
      System.out.println(" ");
    }
  }

  /**
   * Counts the territories for each player.
   * @return an int[2] object containing Player 1's score and Player 2's score.
   */
  public int[] countTerritories() {
    TerritoryMap map = new TerritoryMap(boardSize);
    for (int x = 0; x < boardSize; x++) {
      for (int y = 0; y < boardSize; y++) {
        final int[] coord = {x, y};
        //want to check one point in each area that does not have pieces
        if (getPoint(coord).getState() == PiecePoint.NEUTRAL_STATE
            && !map.getCheckState(coord)
        ) {
          int terr = getTerritory(coord);
          resetCheck();
          updateTerritories(coord, terr, map);
          resetCheck();
        }
      }
    }
    return map.countTerritories();
  }

  /**
   * Starting at a piece that has just been placed process any new captures.
   * @param x the x coordinate of the point to start at.
   * @param y the y coordinate of the point to start at.
   * @return the number of points captured.
   */
  public int captureFromPiece(final int x, final int y) {
    PiecePoint thisPoint = getPoint(x, y);
    if (thisPoint.getState() == PiecePoint.NEUTRAL_STATE) {
      return 0; //Cannot capture points from point with no piece
    }
    int oppositeState; //the state that points we can capture will be in
    if (thisPoint.getState() == PiecePoint.P1_STATE) {
      oppositeState = PiecePoint.P2_STATE;
    } else {
      oppositeState = PiecePoint.P1_STATE;
    }
    //Check from each adjacent point of the opposite colour to find captures
    int[][] adjacentPoints = thisPoint.getAdjacentPoints();
    int captureCount = 0;
    for (int i = 0; i < adjacentPoints.length; i++) {
      if (getPoint(adjacentPoints[i]).getState() == oppositeState) {
        boolean captured = getCapturedStatus(adjacentPoints[i], oppositeState);
        resetCheck();
        if (captured) {
          captureCount += capturePieces(
              adjacentPoints[i],
              oppositeState,
              captureCount
          );
          resetCheck();
        }
      }
    }
    return captureCount;
  }

   /**
    * Checks a newly placed piece to see if placement causes self capture.
    * @param x the x coordinate of the piece to check.
    * @param y the y coordinate of the piece to check.
    * @return true if self capture is found, false otherwise.
    */
  public boolean captureSelf(final int x, final int y) {
    PiecePoint thisPoint = getPoint(x, y);
    if (thisPoint.getState() == PiecePoint.NEUTRAL_STATE) {
      return false; //Cannot capture point from point with no piece
    }
    return getCapturedStatus(thisPoint.getCoordinate(), thisPoint.getState());
  }

  /**
   * Check if this BoardState is equal to another.
   * @param otherBoard the board to compare against.
   * @return true if boards equal, false otherwise.
   */
  public boolean equals(final BoardState otherBoard) {
    if (boardSize == otherBoard.getSize()) {
      for (int x = 0; x < boardSize; x++) {
        for (int y = 0; y < boardSize; y++) {
          if (!getPoint(x, y).equals(otherBoard.getPoint(x, y))) {
            return false;
          }
        }
      }
      return true;
    } else {
      return false;
    }
  }

  /**
   * Set BoardState object to be equal to another BoardState object.
   * @param otherBoard the board to compare against.
   * @throws IllegalAccessException where boards are not of equal size.
   */
  public void setEqualTo(final BoardState otherBoard) {
    if (boardSize != otherBoard.getSize()) {
      throw new IllegalArgumentException(
        "Cannot set equal to a board of different size"
      );
    }
    for (int x = 0; x < boardSize; x++) {
      for (int y = 0; y < boardSize; y++) {
        getPoint(x, y).setEqualTo(otherBoard.getPoint(x, y));
      }
    }
  }

    /**
   * Checks outward from a point to see whose territory it should belong to.
   * @param coord the coordinate of the point to check.
   * @return the value that the territory should be set to.
   */
  private int getTerritory(final int[] coord) {
    PiecePoint thisPoint = getPoint(coord);
    thisPoint.setChecked(true); //We only want to check each point once
    if (thisPoint.getState() != PiecePoint.NEUTRAL_STATE) {
      return thisPoint.getState();
    }
    //find adjacent points to our point that we haven't checked yet
    int[][] adjacentPoints = thisPoint.getAdjacentPoints();
    int uncheckedCount = 0;
    for (int i = 0; i < adjacentPoints.length; i++) {
      if (!getPoint(adjacentPoints[i]).getChecked()) {
        uncheckedCount++;
      }
    }
    int[][] uncheckedAdjacentPoints = new int[uncheckedCount][2];
    if (uncheckedAdjacentPoints.length == 0) {
      return PiecePoint.FALSE_STATE; //We ignore these
    }
    int j = 0;
    for (int i = 0; i < adjacentPoints.length; i++) {
      if (!getPoint(adjacentPoints[i]).getChecked()) {
        uncheckedAdjacentPoints[j] = adjacentPoints[i];
        j++;
      }
    }
    //recursively apply to each unchecked adjacent point and store results
    int[] results = new int[uncheckedAdjacentPoints.length];
    for (int i = 0; i < uncheckedAdjacentPoints.length; i++) {
      results[i] = getTerritory(uncheckedAdjacentPoints[i]);
    }
    //We want to ignore FALSE_STATEs and otherwise return 0 if all values are
    //not the same and the value they share otherwise
    int firstVal = 0;
    for (int i = 0; i < results.length; i++) {
      if (results[i] != PiecePoint.FALSE_STATE) {
        firstVal = results[i];
      }
    }
    boolean alLFalseOrSame = true;
    for (int i = 0; i < results.length; i++) {
      if (results[i] != PiecePoint.FALSE_STATE) {
        if (results[i] != firstVal) {
          alLFalseOrSame = false;
        }
      }
    }
    if (alLFalseOrSame) {
      return firstVal;
    } else {
      return PiecePoint.NEUTRAL_STATE;
    }
  }

  /**
   * Updates points in the same territory as the given point to new value.
   * @param coord the coordinate of the point to start from.
   * @param terr the new territory value to update points to.
   * @param map the TerritoryMap object used to track our results.
   */
  private void updateTerritories(
      final int[] coord,
      final int terr,
      final TerritoryMap map
  ) {
    PiecePoint thisPoint = getPoint(coord);
    thisPoint.setChecked(true); //We only want to check each point once
    if (thisPoint.getState() != PiecePoint.NEUTRAL_STATE) {
      return;
    }
    map.setTerritory(coord, terr);
    int[][] adjacentPoints = thisPoint.getAdjacentPoints();
    for (int i = 0; i < adjacentPoints.length; i++) {
      if (!getPoint(adjacentPoints[i]).getChecked()) {
        updateTerritories(adjacentPoints[i], terr, map);
      }
    }
  }

  /**
   * Checks whether a particular point has been captured.
   * @param coord the coordinate of the point to check.
   * @param state the state representing the player's tokens being captured.
   * @return true if point captured, false otherwise.
   */
  private Boolean getCapturedStatus(final int[] coord, final int state) {
    PiecePoint thisPoint = getPoint(coord);
    thisPoint.setChecked(true); //We only want to check each point once
    int checkState = thisPoint.getState();
    if (checkState != state) {
      return true;
    }
    if (thisPoint.getLiberties() != 0) {
      return false; //Point with liberties remaining cannot be captured
    }
    //find adjacent points to our point that we haven't checked yet
    int[][] adjacentPoints = thisPoint.getAdjacentPoints();
    int uncheckedCount = 0;
    for (int i = 0; i < adjacentPoints.length; i++) {
      if (!getPoint(adjacentPoints[i]).getChecked()) {
        uncheckedCount++;
      }
    }
    int[][] uncheckedAdjacentPoints = new int[uncheckedCount][2];
    if (uncheckedAdjacentPoints.length == 0) {
      return true;
    }
    int j = 0;
    for (int i = 0; i < adjacentPoints.length; i++) {
      if (!getPoint(adjacentPoints[i]).getChecked()) {
        uncheckedAdjacentPoints[j] = adjacentPoints[i];
        j++;
      }
    }
    //recursively apply to each unchecked adjacent point
    //we onlt want to return true if ALL are true
    int i = 0;
    boolean result = true;
    while (i < uncheckedAdjacentPoints.length && result) {
      result = result & getCapturedStatus(uncheckedAdjacentPoints[i], state);
      i++;
    }
    return result;
  }

  /**
   * Apply capture to pieces starting from one point in a known captured block.
   * @param coord the coordinate of the starting point.
   * @param state the state of points to capture.
   * @param captureCount the number of captured points (should initially be 0).
   * @return the number of points captured.
   */
  private int capturePieces(
      final int[] coord,
      final int state,
      final int captureCount
  ) {
    int newCaptureCount = captureCount;
    PiecePoint thisPoint = getPoint(coord);
    thisPoint.setChecked(true); //We only want to check each point once
    if (thisPoint.getState() != state) {
      return newCaptureCount; //only capture points of given state
    }
    //remove captured piece from board
    thisPoint.updateState(PiecePoint.NEUTRAL_STATE);
    newCaptureCount++;
    //recursively apply to adjacent points
    int[][] adjacentPoints = thisPoint.getAdjacentPoints();
    for (int i = 0; i < adjacentPoints.length; i++) {
      getPoint(adjacentPoints[i]).increaseLiberties();
      if (!getPoint(adjacentPoints[i]).getChecked()) {
        newCaptureCount = capturePieces(
          adjacentPoints[i],
          state,
          newCaptureCount
        );

      }
    }
    return newCaptureCount;
  }

  /**
   * Resets the check status of all points on the board.
   * This needs to be run after each instance of a method using checks.
   */
  private void resetCheck() {
    for (int x = 0; x < boardSize; x++) {
      for (int y = 0; y < boardSize; y++) {
        getPoint(x, y).setChecked(false);
      }
    }
  }
}
